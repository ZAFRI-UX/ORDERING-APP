# CoffeeOrderingApp
I developed this Android app during my diploma studies as a hands-on way to learn mobile development from the ground up. Using Android Studio, the official IDE for Android, I took on the challenge of building an app independently, from the first screen to a working project.

What I Learned:
Building the app taught me far more than writing code alone. I learned how each part of the code works and how the pieces connect to form a complete application. I also gained insight into how the system runs behind the scenes, including how an app moves through its lifecycle, how activities and components interact, and how tasks are handled in the background. Along the way, I practiced designing user interfaces, testing on the emulator, and debugging problems, which taught me to be patient and to think through errors step by step.As a beginner, this project gave me a solid foundation.
